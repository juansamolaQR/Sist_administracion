<?php
include('connection.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['nombre'];
    $password = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
    $cargo = $_POST['cargo'];
    $sql = "INSERT INTO `usuarios` ( `nombre`, `contrasena`, `cargo`, `estado`) VALUES ('$username','$password','$cargo','1')";
    $response = mysqli_query($connection, $sql);
    echo mysqli_error($connection);
}
$connection->close();
?>