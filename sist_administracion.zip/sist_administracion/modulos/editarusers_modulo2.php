<?php
include('connection.php');

$id = $_GET['id'];

$getquery = "SELECT * FROM `usuarios` where id = $id";

$resultadoget = mysqli_query($connection,$getquery);

while($row=mysqli_fetch_array($resultadoget))
    {
        echo '<input type="text" class="form-control" id="nombre" placeholder="'.$row['nombre'].'">';
        echo '<input type="password" id="contrasena" class="form-control" placeholder="'.$row['contrasena'].'">';
        if($row['cargo'] == 0){
            echo '<select class="form-select" aria-label="Default select example" id="cargo">
                    <option value="0">Dueño</option>
                    <option value="1">Administrador</option>
                    <option value="2">Subadministrador</option>
                    <option value="3">Empleado</option>
                    </select>';
         } else if($row['cargo'] == 1){
            echo '<select class="form-select" aria-label="Default select example" id="cargo">
            <option value="1">Administrador</option>
            <option value="0">Dueño</option>
            <option value="2">Subadministrador</option>
            <option value="3">Empleado</option>
            </select>';
         } else if($row['cargo'] == 2){
            echo '<select class="form-select" aria-label="Default select example" id="cargo">
            <option value="2">Subadministrador</option>
            <option value="0">Dueño</option>
            <option value="1">Administrador</option>
            <option value="3">Empleado</option>
            </select>';
         } else if($row['cargo'] == 3){
            echo '<select class="form-select" aria-label="Default select example" id="cargo">
            <option value="3">Empleado</option>
            <option value="0">Dueño</option>
            <option value="1">Administrador</option>
            <option value="2">Subadministrador</option>
            </select>';
         }
         if($row['estado'] == 0){
            echo '<select class="form-select" aria-label="Default select example" id="estado">
            <option value="0">Inactivo</option>
            <option value="1">Activo</option>
            </select>';
        } else if($row['estado'] == 1){
            echo '<select class="form-select" aria-label="Default select example" id="estado">
            <option value="1">Activo</option>
            <option value="0">Inactivo</option>
            </select>';
        }
    }
    ;
?>