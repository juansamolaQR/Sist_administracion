<?php
include('connection.php');

$getquery = "SELECT * FROM `usuarios`";

$resultadoget = mysqli_query($connection,$getquery);

while($row=mysqli_fetch_array($resultadoget))
    {
        echo "<tr>
        <th scope='row'>".$row['id']."</th>
        <td>".$row['nombre']."</td>
        <td>".$row['contrasena']."</td>";
        if($row['cargo'] == 0){
           echo '<td>Dueño</td>';
        } else if($row['cargo'] == 1){
            echo '<td>Administrador</td>';
        } else if($row['cargo'] == 2){
            echo '<td>Subadministrador</td>';
        } else if($row['cargo'] == 3){
            echo '<td>Empleado</td>';
        }
        if($row['estado'] == 0){
            echo '<td>Inactivo</td>';
        } else if($row['estado'] == 1){
            echo '<td>Activo</td>';
        }
        echo '<td><button type="button" onclick="editar('.$row['id'].')" class="btn btn-success">Editar</button></td>';
        echo "</tr>";
    }
    echo '</table>';
?>