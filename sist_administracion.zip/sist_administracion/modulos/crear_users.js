function register(ev) {
ev.preventDefault();
var nombre = document.getElementById('nombre').value;
var contrasena = document.getElementById('contrasena').value;
var cargo = document.getElementById('cargo').value;
const data = {
  nombre: nombre,
  contrasena: contrasena,
  cargo: cargo
};
$.ajax({
    type: 'POST',
    url: "modulos/crear_users.php",
    data: data,
    success: function(response){
        console.log(response);
        Swal.fire({
            title: "Registrado con éxito",
            confirmButtonText: "OK"
          }).then((result) => {
            if (result.isConfirmed) {
                location.reload();
}})
}})
}
