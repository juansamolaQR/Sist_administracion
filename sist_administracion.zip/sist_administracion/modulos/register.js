function ansValidation(ev) {
    var passValue = document.getElementById("password").value;
var confpassValue = document.getElementById("confirmPassword").value;
if(passValue !== confpassValue) {
    document.getElementById("password").setCustomValidity('Las contraseñas no coinciden');
    document.getElementById("confirmPassword").setCustomValidity('Las contraseñas no coinciden');
} else if(passValue == confpassValue) {
document.getElementById("password").setCustomValidity('');
    document.getElementById("confirmPassword").setCustomValidity('');
}
if (!document.getElementById("confirm").checked) {
document.getElementById("confirm").setCustomValidity("Por favor verificar este campo");
} else if (document.getElementById("confirm").checked) {
document.getElementById("confirm").setCustomValidity("");
}
let isFormValid = $('#form')[0].checkValidity();
   if(!isFormValid) {
        $('#form').reportValidity();
    } else{
        ev.preventDefault();
var nombre = document.getElementById('nombre').value;
var contrasena = document.getElementById('password').value;
const data = {
  nombre: nombre,
  contrasena: contrasena
};
$.ajax({
    type: 'POST',
    url: "modulos/register_module.php",
    data: data,
    success: function(response){
        console.log(response);
        Swal.fire({
            title: "Registrado con éxito",
            confirmButtonText: "OK"
          }).then((result) => {
            if (result.isConfirmed) {
                location.href = "login.php";
}})
}})
}}
