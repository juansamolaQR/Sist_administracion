$(document).ready(function() {
    $.ajax({
        url     : 'modulos/editarusers_modulo.php',
        data    : {},
        type    : 'GET',
        success : function(resp){
            $("#editarusers").html(resp);
        },
        error   : function(resp){
        }  
    });
});

function editar(idusuario){
    $.ajax({
        url     : 'modulos/editarusers_modulo2.php',
        data    : {id:idusuario},
        type    : 'GET',
        success : function(resp){
            Swal.fire({
                title: "Edición de usuario (modificar todos los campos)",
                html: resp,
                confirmButtonText: "OK"
              }) .then((result) => {
                if (result.isConfirmed) {
                    var nombre = document.getElementById('nombre').value;
                    var contrasena = document.getElementById('contrasena').value;
                    var cargo = document.getElementById('cargo').value;
                    var estado = document.getElementById('estado').value;
                    const data = {
                        id: idusuario,
                      nombre: nombre,
                      contrasena: contrasena,
                      cargo: cargo,
                      estado: estado
                    };
                    }
              })
            }})
        }

function myModify(modifyid){
    $.ajax({
        url     : 'modules/edit_products_admin.php',
        data    : {id:modifyid},
        type    : 'GET',
        success : function(resp){
            Swal.fire({
                title: "Edición de producto",
                html: resp,
                confirmButtonText: "OK"
              }) .then((result) => {
                if (result.isConfirmed) {
                    var edit_titulo = document.getElementById('edit_titulo').value;
                    var edit_descripcion = document.getElementById('edit_descripcion').value;
                    var edit_precio = document.getElementById('edit_precio').value;
                    const data1 = {
                        id: modifyid,
                        nombre: edit_titulo,
                        descripcion: edit_descripcion,
                        precio: edit_precio
                      };
                      
                    $.ajax({
                        type: 'POST',
                        url: "modules/edit_products_add.php",
                        data: data1,
                        success: function(response){
                            console.log(response);
                           if(response == "OK"){
                            Swal.fire({
                                title: "Producto editado",
                                confirmButtonText: "OK"
                              }).then((result) => {
                                if (result.isConfirmed) {
                                    location.reload();
                    }})
                    } else{
                        Swal.fire({
                            title: "Producto ya registrado",
                            text: "Ese producto ya se encuentra en la base de datos",
                            confirmButtonText: "OK"
                          })
                    }
                    
                    }})
              }
        } 
              )}
  }) 
}


