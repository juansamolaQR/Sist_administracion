$(document).ready(function() {
    $.ajax({
        url     : 'modulos/verusers_modulo.php',
        data    : {},
        type    : 'GET',
        success : function(resp){
            $("#verusers").html(resp);
        },
        error   : function(resp){
        }  
    });
});