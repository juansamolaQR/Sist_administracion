<?php
include('connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $datosJSON = file_get_contents('php://input');
    $datos = json_decode($datosJSON, true);

    if (isset($datos["user"]) && isset($datos["pass"])) {
        $user = $datos["user"];
        $pass = $datos["pass"];
        
        $consulta_usuario = "SELECT * FROM `usuarios` WHERE nombre = '$user'";
        $resultado_usuario = $connection->query($consulta_usuario);

        if ($resultado_usuario->num_rows > 0) {
            $fila = $resultado_usuario->fetch_assoc();
            $id = $fila['id'];
            $user = $fila['nombre'];
            $contrasena = $fila['contrasena'];
            $cargo = $fila['cargo'];
            $estado = $fila['estado'];

                if (password_verify($pass, $contrasena)){

                if ($estado == 1) {
                    session_start();
                    $_SESSION['id'] = $id;
                    $_SESSION['user'] = $user;
                    $_SESSION['cargo'] = $cargo;
                    $_SESSION['estado'] = $estado;

                    if ($cargo == 0) {
                        $_SESSION['cargo'] = "Dueño";
                        http_response_code(200);
                        echo "0";
                        exit;
                    } elseif ($cargo == 1) {
                        $_SESSION['cargo'] = "Administrador";
                        http_response_code(200);
                        echo "1";
                        exit;
                    } elseif ($cargo == 2) {
                        $_SESSION['cargo'] = "Subadministrador";
                        http_response_code(200);
                        echo "2";
                        exit;
                    } elseif ($cargo == 3) {
                        $_SESSION['cargo'] = "Empleado";
                        http_response_code(200);
                        echo "3";
                        exit;
                    }
                    else {
                        http_response_code(400); // Código de estado de error de solicitud
                        echo json_encode(array('success' => false, 'message' => 'Cargo desconocido'));
                        exit;
                    }
                } else {
                    http_response_code(400); // Código de estado de error de solicitud
                    echo json_encode(array('success' => false, 'message' => 'Usuario o área desactivados'));
                    exit;
                }
            }
        } else {
            http_response_code(400); // Código de estado de error de solicitud
            echo json_encode(array('success' => false, 'message' => 'Usuario no encontrado'));
            exit;
        }
}
} else {
    exit();
}
?>