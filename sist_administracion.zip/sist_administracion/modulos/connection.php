<?php
    $nombreServidor = "127.0.0.1:3307";
    $usuario = "root";
    $contraseñaBD = "";
    $baseDeDatos = "sist_administracion";
    $connection =  mysqli_connect($nombreServidor, $usuario, $contraseñaBD, $baseDeDatos);
     // Establecer la zona horaria a Buenos Aires
    date_default_timezone_set('America/Argentina/Buenos_Aires');

    if ($connection->connect_error) {
        die("Conexión fallida: " . $conexion->connect_error);
    }
    else
    {
        //echo "conectado";
    }
?>