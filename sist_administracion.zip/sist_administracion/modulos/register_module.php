<?php
include('connection.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['nombre'];
    $password = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
    $sql = "INSERT INTO `usuarios` ( `nombre`, `contrasena`, `cargo`, `estado`) VALUES ('$username','$password','3','1')";
    $response = mysqli_query($connection, $sql);
    echo mysqli_error($connection);
}
$connection->close();
?>