document.getElementById('login').addEventListener('click', function(){
    
    const userInput = document.getElementById('username');
    const userLogin = userInput.value.trim();

    const passInput= document.getElementById('password');
    const passLogin = passInput.value.trim();

    if (userLogin !== '' && passLogin !== '') {
        loginVerificacion(userLogin, passLogin);
        userLogin.value = '';
        passInput.value = '';
    } else {
        alert('Por favor ingrese su usuario y contraseña');
    }
})

function loginVerificacion(user, pass) { 

    $.ajax({

        url: 'modulos/loginuser.php',
        
        type: 'POST',
        
        contentType: 'application/json',
        
        data: JSON.stringify({ user: user, pass: pass }), // JSON data
        
        success: function(response) { // Success callback
        
        console.log('Success:', response);
         if (response == 0){
            window.location.href = 'admin.php';
         };
         if (response == 1){
            window.location.href = 'admin.php';
         };

        
        },
        
        error: function(error) { // Error callback
        
        console.error('Error:', error);
        
        }
        
        })
    }