<?php 
session_start();
?>
<!doctype html>

<html lang="en"> 

 <head> 

  <meta charset="UTF-8"> 

  <title>Dashboard de administración</title> 

  <link rel="stylesheet" href="style2.css"> 

 </head>

 <body>
    <?php 
    if ($_SESSION['cargo'] == 'Dueño'){
        echo '<ul>
    <li><a href="ver_usuarios.php" data-text="Ver usuarios">Ver usuarios</a></li>
    <li><a href="crear_usuarios.php" data-text="Crear usuarios">Crear usuarios</a></li>
    <li><a href="editar_usuarios.php" data-text="Editar usuarios">Editar usuarios</a></li>
    <li><a href="https://youtu.be/SpbRY1IRUko" data-text="Eliminar usuarios">Eliminar usuarios</a></li>
    <li><a href="https://youtu.be/SpbRY1IRUko" data-text="Generar PDF">Generar PDF</a></li>
    <li><a href="https://youtu.be/SpbRY1IRUko" data-text="Generar Word">Generar Word</a></li>
    <li><a href="https://youtu.be/SpbRY1IRUko" data-text="Generar Excel">Generar Excel</a></li>
  </ul>';
    }
    ?>
</body>
</html>