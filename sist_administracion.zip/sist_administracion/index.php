<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <link rel="stylesheet" href="styles/style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   </head>
<body>
  <div class="wrapper">
    <h2>Registrarse</h2>
    <form id="form" name="form">
      <div class="input-box">
        <input type="text" id="nombre" name="nombre" placeholder="Ingresar nombre" required>
      </div>
      <div class="input-box">
        <input type="password" id="password" name="password" placeholder="Ingresar contraseña" required>
      </div>
      <div class="input-box">
        <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirmar contraseña" required>
      </div>
      <div class="policy">
        <input type="checkbox" id="confirm" name="confirm">
        <h3>Aceptar términos y condiciones</h3>
      </div>
      <div class="input-box button">
        <input type="submit" onClick="ansValidation(event)" value="Registrarse">
      </div>
      <div class="text">
        <h3>¿Ya tienes una cuenta? <a href="login.php">Iniciar sesión</a></h3>
      </div>
    </form>
  </div>
        <script src="modulos/jquery.js"></script>
        <script src="modulos/register.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
</body>
</html>
