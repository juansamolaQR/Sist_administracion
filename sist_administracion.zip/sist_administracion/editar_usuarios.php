<?php 
session_start();
?>
<!doctype html>

<html lang="en"> 

 <head> 

  <meta charset="UTF-8"> 

  <title>Ver usuarios</title> 
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="style2.css"> 
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
 </head>

 <body>
 <a href="admin.php"><button type="button" class="btn btn-danger" style="position:absolute; top:2%; left:1%;">Volver</button></a>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-12">
            <div class="table-responsive">
              <table class="table table-dark table-bordered mb-0">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Contraseña (cifrada)</th>
                    <th scope="col">Cargo</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Editar</th>
                  </tr>
                </thead>
                <tbody id="editarusers">
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    <script src="modulos/jquery.js"></script>
    <script src="modulos/editar_users.js"></script>
</body>
</html>